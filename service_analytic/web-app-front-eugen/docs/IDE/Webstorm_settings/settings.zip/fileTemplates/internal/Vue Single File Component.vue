<template>
  <div :class="#[[$style]]#.${COMPONENT_NAME}">
    #[[$END$]]#
  </div>
</template>
<script>
  export default {
      name: '${COMPONENT_NAME}'
  };
</script>
<style lang="scss" module>
    .${COMPONENT_NAME} {
        //
    }
</style>